#include <Arduino.h>
#include <TFT_eSPI.h>
#include "image.h"

TFT_eSPI tft = TFT_eSPI();

void setup() {
  tft.init();
  tft.setRotation(0);
  tft.pushImage(0, 0, 240, 320, image);
}

void loop() {
}
