# ESP32 TFT image project

This project targets a generic ESP32 Dev Module with an SPI ILI9341 240x320 TFT.

Pins configured:
- SCK 18
- MOSI 23
- MISO 19
- CS 5
- DC 2
- RST 4

The GitHub Actions workflow compiles the project and stores `firmware.bin` as an artifact.

Important: this assumes the display really uses ILI9341 and the pin wiring matches the list above. If your display has different pins or controller, change `platformio.ini`.
